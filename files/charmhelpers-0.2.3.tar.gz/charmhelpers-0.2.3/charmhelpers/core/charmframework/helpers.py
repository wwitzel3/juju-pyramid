# Copyright 2014-2015 Canonical Limited.
#
# This file is part of charm-helpers.
#
# charm-helpers is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License version 3 as
# published by the Free Software Foundation.
#
# charm-helpers is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with charm-helpers.  If not, see <http://www.gnu.org/licenses/>.

import os
import yaml
from functools import partial
from charmhelpers.core import hookenv
from charmhelpers.core import templating

from charmhelpers.core import unitdata


class Relation(object):
    """
    Base class for relation handler classes.


    Note: The default constructor allows any pre-defined class attribute to be
    overridden via kwargs during instantiation.  Thus, the above variables can
    be set or overridden when constructing the relation or a subclass.  For example,
    the following will override both the ``optional`` flag and the ``port``::

        class MyRelation(Relation):
            relation_name = 'foo'
            port = 80

        rel = MyRelation(optional=True, port=8080)

    """
    relation_name = None
    """
    Name (*not* interface) of the relation to manage.
    """

    required_keys = []
    """
    List of keys that must be set on the relation for it to be considered ready
    (i.e., pass when used as a ``requires`` predicate).  If no keys are defined,
    then a relation is considered ready if a unit is attached.
    """

    optional = False
    """
    Whether the relation is optional.  An optional relation always passes when
    used as a predicate, even if no units are connected.  However, it is still
    useful to include them in the ``requires`` section, because it is both
    informative when reading the definition and allows the framework to
    automatically call :meth:`store_data`.
    """

    def __init__(self, **kwargs):
        for attr, value in kwargs.items():
            if not hasattr(self, attr):
                raise AttributeError(
                    "'%s' class has no attribute '%s' to override"
                    % (type(self).__name__, attr))
            setattr(self, attr, value)
        if self.relation_name is None:
            raise AttributeError(
                "Required 'relation_name' set by neither '%s' class nor instantation"
                % type(self).__name__)
        if not hasattr(self, 'datastore'):
            self.datastore = unitdata.kv()
        if not hasattr(self, 'cache'):
            self.cache = hookenv.cache

    def __str__(self):
        units_info = []
        for unit, data in self.unfiltered_data().items():
            missing_keys = set(self.required_keys) - set(data.keys())
            if missing_keys:
                unit_info = "missing({})".format(', '.join(missing_keys))
            else:
                unit_info = "ready"
            units_info.append('{}={}'.format(unit, unit_info))
        return '<{name} ready={ready} {units}>'.format(
            name=type(self).__name__,
            ready=self.is_ready(),
            units=' '.join(units_info),
        )

    def __bool__(self):
        return self.is_ready()

    def __nonzero__(self):
        return self.is_ready()

    def _unit_ready(self, unit_name, unit_data):
        """
        Check the data for a single unit and indicate whether that unit is ready.
        """
        return set(unit_data.keys()).issuperset(set(self.required_keys))

    def connected_units(self):
        """
        Returns a list of the names of all units connected on this relation.
        """
        cache_key = 'Relation.connected_units(%s)' % self.relation_name
        if cache_key in hookenv.cache:
            return hookenv.cache[cache_key]
        units = []
        for relid in hookenv.relation_ids(self.relation_name):
            for unit in hookenv.related_units(relid):
                units.append(unit)
        hookenv.cache[cache_key] = units
        return units

    def unfiltered_data(self):
        """
        Get all relation data for any unit connected to this relation.

        :returns: Mapping (*dict*) of unit name to that unit's data *dict*.
        """
        cache_key = 'Relation.unfiltered_data(%s, %s)' % (
            self.relation_name, self.required_keys)
        if cache_key not in self.cache:  # cache for the duration of the hook
            self.cache[cache_key] = data = {}
            for relid in hookenv.relation_ids(self.relation_name):
                for unit in hookenv.related_units(relid):
                    data[unit] = hookenv.relation_get(unit=unit, rid=relid)
        return self.cache[cache_key]

    def filtered_data(self, remote_service=None):
        """
        Get the data from :meth:`unfiltered_data` and filter it to only include
        units which have set all of the ``required_keys``.

        :param str remote_service: If given, additionally filter to only include
            data for units of a single service (useful in :meth:`provide` methods).

        :returns: Mapping (*dict*) of unit name to that unit's data *dict*.
        """
        cache_key = 'Relation.filtered_data(%s, %s)' % (
            self.relation_name, self.required_keys)
        if cache_key not in self.cache:  # cache for the duration of the hook
            self.cache[cache_key] = filtered_data = {}
            for unit_name, unit_data in self.unfiltered_data().iteritems():
                if self.unit_ready(unit_name, unit_data):
                    filtered_data[unit_name] = unit_data

        filtered_data = self.cache[cache_key]
        if remote_service is not None:
            filtered_data = {k: v
                             for k, v in filtered_data.iteritems()
                             if k.startswith(remote_service)}
        return filtered_data

    def store_data(self):
        """
        Store all filtered relation data is stored in
        :class:`unitdata <charmhelpers.core.unitdata.Storage>` under ``relations.ready``.

        The data can be retrieved using::

            from charmhelpers.core import unitdata
            data = unitdata.kv().get('relations.ready')[relation_name][unit_name]

        However, it is generally recommended to use one of :func:`any_ready_unit` or
        :func:`all_ready_units`.

        This method is called automatically for all ``Relation`` subclasses
        as predicates in the ``required`` section of a definition.
        """
        stored_data = self.datastore.get('relations.ready', {})
        stored_data[self.relation_name] = self.filtered_data()
        self.datastore.set('relations.ready', stored_data)

    def provide(self, remote_service, all_ready):
        """
        Provide data to the other side of the relation.

        This should be implemented by subclasses.

        :param str remote_service: Name of the remote service to which this
            relation will be providing data
        :param bool all_ready: Whether all ``requires`` predicates for this
            Charm component have been met and the callbacks run
        """
        return {}

    def is_ready(self):
        """
        Determine if this relation is "ready".

        A relation is ready if it is not optional and there is at least one
        unit that satisfies all of the ``required_keys``.  (Optional
        relations are always considered ready.)

        Note: A `Relation` instance can also be evaluated directly (e.g., via
        ``bool()``) to test its readiness.
        """
        filtered_data = self.filtered_data()
        return self.optional or len(filtered_data) > 0


class HttpRelation(Relation):
    """
    Relation subclass for handling relations using the ``http`` interface protocol.

    As mentioned in :class:`Relation`, all variables (including `port`) can be
    overridden when instantiating the class.
    """
    relation_name = 'website'
    required_keys = ['host', 'port']
    port = 80
    """
    Port upon which this service is listening.
    """

    def provide(self, remote_service, all_ready):
        return {
            'host': hookenv.unit_get('private-address'),
            'port': self.port,
        }


class MySQLRelation(Relation):
    """
    Relation subclass for handling relations using the ``mysql`` interface protocol.

    As mentioned in :class:`Relation`, all variables (including `dsn_format`) can be
    overridden when instantiating the class.
    """
    relation_name = 'db'
    required_keys = ['host', 'user', 'password', 'database']
    dsn_format = 'mysql://{user}:{password}@{host}/{database}'
    """
    In addition to the :attr:`required_keys`, a ``dsn`` value is constructed, based
    on this format string, and added to the :meth:`filtered_data`.
    """

    def filtered_data(self, remote_service=None):
        """
        Get the filtered data, as per :meth:`Relation.filtered_data`, and add
        a ``dsn`` entry constructed from the other values.
        """
        data = super(MySQLRelation, self).filtered_data(remote_service)
        for unit_name, unit_data in data.items():
            unit_data['dsn'] = self.dsn_format.format(**unit_data)
        return data


def config_eq(option, value):
    """
    Predicate helper that asserts that the given config option is equal to
    the given value.

    Values of ``None`` are normalized to empty strings, since it is impossible
    to properly "unset" a config value once it has been set; it can only be
    set to an empty string.

    For example::

        Manager([
            {
                'requires': [config_eq('unstable', False)],
                'callbacks': [install_stable],
            },
            {
                'requires': [config_eq('unstable', True)],
                'callbacks': [install_unstable],
            },
        ])

    In this case, only one of ``install_stable`` or ``install_unstable`` will
    ever be called, depending on the value of the 'unstable' config option.
    """
    def _config_eq():
        expected_value = value
        current_value = hookenv.config().get(option)
        if expected_value is None:
            expected_value = ''
        if current_value is None:
            current_value = ''
        return current_value == expected_value
    return _config_eq


def config_ne(option, value):
    """
    Predicate helper that asserts that the given config option is not equal
    to the given value.

    Values of ``None`` are normalized to empty strings, since it is impossible
    to properly "unset" a config value once it has been set; it can only be
    set to an empty string.
    """
    def _config_ne():
        unexpected_value = value
        current_value = hookenv.config().get(option)
        if unexpected_value is None:
            unexpected_value = ''
        if current_value is None:
            current_value = ''
        return current_value != unexpected_value
    return _config_ne


def config_not_default(option):
    """
    Predicate helper that asserts that the given config option is not equal
    to its default value.

    Values of ``None`` are normalized to empty strings, since it is impossible
    to properly "unset" a config value once it has been set; it can only be
    set to an empty string.
    """
    def _config_not_default():
        with open(os.path.join(hookenv.charm_dir(), 'config.yaml')) as fp:
            options = yaml.load(fp).get('options', {})
            default_value = options.get(option).get('default')
        current_value = hookenv.config().get(option)
        if default_value is None:
            default_value = ''
        if current_value is None:
            current_value = ''
        return current_value != default_value
    return _config_not_default


def config_is_set(option):
    """
    Predicate helper that asserts that the given config option is set to a
    non-empty / non-``None`` value.

    This is equivalent to :func:`config_ne(option, '') <config_ne>`, but
    can be a bit more clear.
    """
    return config_ne(option, '')


def render_template(source, target, context=None, owner='root', group='root', perms=0o444):
    """
    Callback helper that will render a Jinja2 template.

    The template is provided a context which contains these items by default:

      * ``ctx``: Return value from :func:`charmhelpers.core.hookenv.execution_environment`
      * ``config``: Mapping of all config options and values
      * ``unitdata.kv``: The :class:`~charmhelpers.core.unitdata.Storage` instance
        interface from :mod:`charmhelpers.core.unitdata`
      * ``any_ready_unit``: The :func:`any_ready_unit` helper
      * ``all_ready_units``: The :func:`all_ready_units` helper
      * ``all_ready_units``: The :func:`all_ready_units` helper
      * ``config_not_default``: A helper that uses the :func:`config_not_default`
        predicate to check if a config option has been changed

    :param str source: The template source file, relative to ``$CHARM_DIR/templates``
    :param str target: The target to write the rendered template to
    :param dict context: Additional context to be provided to the template
    :param str owner: The owner of the rendered file (default: root)
    :param str group: The group of the rendered file (default: root)
    :param int perms: The permissions of the rendered file (default 0o444)
    """
    def _template():
        _context = dict(context,
                        ctx=hookenv.execution_environment(),
                        config=hookenv.config(),
                        unitdata={'kv': unitdata.kv()},
                        any_ready_unit=any_ready_unit,
                        all_ready_units=all_ready_units,
                        config_not_default=lambda o: config_not_default(o)())
        return templating.render(source, target, _context, owner, group, perms)
    return _template


def any_ready_unit(relation_name):
    """
    Returns the unit name and data for any single ready unit on the given
    relation.

    If more than one unit is attached and ready, this is **not** guaranteed
    to return the same unit each time it is called.  It is recommended that
    you use :func:`all_ready_units` if you ever expect more than one service
    or unit to be attached.

    This requires that :meth:`Relation.store_data` has been called for the
    given relation, which is done automatically by
    :class:`~charmhelpers.core.charmframework.base.Manager`.

    :param str relation_name: Name of the relation
    :return: Tuple containing ``(unit_name, unit_data)``, or ``(None, None)``
        if no units are ready for the given relation
    """
    units = unitdata.kv().get('relations.ready', {}).get(relation_name)
    if not units:
        return (None, None)
    unit = units.keys()[0]
    return (unit, units[unit])


def all_ready_units(relation_name):
    """
    Returns the unit name and data for all ready untis on the given relation,
    sorted by unit name.

    This requires that :meth:`Relation.store_data` has been called for the
    given relation, which is done automatically by
    :class:`charmhelpers.core.charmframework.base.Manager`.

    :param str relation_name: Name of the relation
    :return list: List of tuples containing ``(unit_name, unit_data)``, or
        an empty list if no units are ready for the given relation
    """
    units = unitdata.kv().get('relations.ready', {}).get(relation_name, {})
    return sorted(units.items())


def open_ports(*ports):
    """
    Callback helper that will open the given ports when called.

    Roughly equivalent to::

        lambda: map(hookenv.open_port, ports)

    However, ports can be given as individual ports (``open_ports(80, 443)``),
    or a list of ports (``open_ports([80, 443])``).
    """
    def _open_ports():
        for port in ports:
            if not isinstance(port, (list, tuple)):
                port = [port]
            for _port in port:
                hookenv.open_port(_port)
    return _open_ports


def close_ports(*ports):
    """
    Callback helper that will close the given ports when called.

    Roughly equivalent to::

        lambda: map(hookenv.open_port, ports)

    However, ports can be given as individual ports (``close_ports(80, 443)``),
    or a list of ports (``close_ports([80, 443])``).
    """
    def _close_ports():
        for port in ports:
            if not isinstance(port, (list, tuple)):
                port = [port]
            for _port in port:
                hookenv.close_port(_port)
    return _close_ports


def service_restart(service_name):
    """
    Callback helper that will restart the given service.

    Equivalent to::

        functools.partial(hookenv.service_restart, service_name)
    """
    return partial(hookenv.service_restart, service_name)


def service_reload(service_name):
    """
    Callback helper that will reload the given service.

    Equivalent to::

        functools.partial(hookenv.service_reload, service_name)
    """
    return partial(hookenv.service_reload, service_name)


def service_stop(service_name):
    """
    Callback helper that will stop the given service.

    Equivalent to::

        functools.partial(hookenv.service_stop, service_name)
    """
    return partial(hookenv.service_stop, service_name)
