# Copyright 2014-2015 Canonical Limited.
#
# This file is part of charm-helpers.
#
# charm-helpers is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License version 3 as
# published by the Free Software Foundation.
#
# charm-helpers is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with charm-helpers.  If not, see <http://www.gnu.org/licenses/>.

from charmhelpers.core import hookenv
from charmhelpers.core import charmdata


class Manager(object):
    def __init__(self, components):
        """
        Register a set of charm components, which define what the charm does.

        Component definitions are dicts in the following format
        (all fields are optional):

            {
                "name": <name of component>,
                "provides": <list of providers>,
                "requires": <list of predicates>,
                "callbacks": <list of callbacks>,
                "cleanup": <list of callbacks>,
            }

        The component ``name`` is just for descriptive purposes.

        The ``provides`` list should contain relation data providers.  These
        will most likely be subclasses of :class:`charmhelpers.core.services.helpers.Relation`,
        but can be any object that has a ``relation_name`` attribute and an
        ``provide`` method, which will be called with the name of the remote
        service and a flag indicating whether the component is "ready", i.e.,
        all ``requires`` predicates returned True.  If a class is given, it will
        be instantiated with no arguments.

        The ``requires`` list should contain predicates that indicate whether a
        given requirement is satisfied.  They can be simple predicate functions,
        or they can be classes (or instances) which support an ``is_ready`` method.
        Additionally, if they support a ``store_data`` method, it will be called
        to store any data for easy access from outside the framework (e.g., in
        templates).  (It is highly recommended that data be stored using
        :class:`charmhelpers.core.charmdata.Storage`.)  Classes will be
        instantiated with no arguments.

        The ``callbacks`` list should contain callbacks that are triggered if all
        of the ``requires`` predicates are satisfied.  They are not passed any
        arguments.

        The 'cleanup' list should contain callbacks that are triggered if the
        charm is being stopped, or if some of the ``requires`` predicates can
        no longer be satisfied (for example, if a required relation was lost).


        Examples:

        The following registers a component which depends on a mongodb relation
        and a ``password`` option being changed from its default value, and which
        runs a custom ``db_migrate`` function, renders a couple of templates,
        starts the system service 'bingod', and finally opens a couple of ports.

            class MongoRelation(ch_framework.helpers.Relation):
                relation_name = 'mongo'
                required_keys = ['hostname', 'port']

            manager = ch_framework.Manager([
                {
                    'provides': [
                        HttpRelation,
                    ],
                    'requires': [
                        MongoRelation,
                        services.helpers.config_not_default('password'),
                    ],
                    'actions': [
                        db_migrate,
                        services.helpers.template(source='bingod.conf'),
                        services.helpers.template(source='bingod.ini',
                                                  target='/etc/bingod.ini',
                                                  owner='bingo', perms=0400),
                        services.helpers.service_restart('bingod'),
                        services.helpers.open_ports(80, 443),
                    ],
                    'cleanup': [
                        services.helpers.close_ports(80, 443),
                        services.helpers.service_stop('bingod'),
                    ],
                },
            ])
            manager.manage()
        """
        self.components = components
        for i, component in enumerate(components):
            component.setdefault('name', 'component-%d' % i)

    def manage(self):
        """
        Handle the current hook by doing The Right Thing with the registered components.
        """
        hook_name = hookenv.hook_name()
        if hook_name == 'stop':
            self.run_cleanup()
        else:
            self.run_callbacks()
            self.provide_data()
        cfg = hookenv.config()
        if cfg.implicit_save:
            cfg.save()

    def provide_data(self):
        """
        Set the relation data for each provider in the ``provides`` list.

        A provider can be a class or an instance, and must have a ``relation_name``
        attribute, which indicates which relation is applies to, and a
        ``provide(remote_service, all_ready)`` method, where ``remote_service``
        is the name of the Juju service on the other end of the relation, and
        ``all_ready`` is a boolean indicating whether all of the requirements
        for the component were satisfied and the callbacks were run.

        Note that the providers are called after the requirements are
        checked and the callbacks (possibly) run, since the callbacks may
        generate some of the data to be provided.
        """
        for component in self.components:
            component_ready = self.is_ready(component)
            for provider in component.get('provides', []):
                if isinstance(provider, type):
                    provider = provider()
                for relid in hookenv.relation_ids(provider.relation_name):
                    units = hookenv.related_units(relid)
                    if not units:
                        continue
                    remote_service = units[0].split('/')[0]
                    data = provider.provide(remote_service, component_ready)
                    if data:
                        hookenv.relation_set(relid, data)

    def run_callbacks(self):
        """
        Check all components' ``requires`` predicates and run either ``callbacks``
        or ``cleanup`` actions.
        """
        for component in self.components:
            self.store_data(component)
            if self.is_ready(component):
                self.fire_event('callbacks', component)
                self.save_ready(component)
            else:
                hookenv.log('Component {} blocked on: [{}]'.format(
                    component['name'],
                    ', '.join(map(str, self.not_ready(component))),
                ))
                if self.was_ready(component):
                    self.fire_event('cleanup', component)
                self.save_lost(component)

    def run_cleanup(self):
        """
        Unconditionally run all components' ``cleanup`` actions.
        """
        for component in self.components:
            self.fire_event('cleanup', component)

    def store_data(self, component):
        for req in component.get('requires', []):
            if isinstance(req, type):
                req = req()
            if hasattr(req, 'store_data'):
                req.store_data()

    def fire_event(self, event_name, component):
        """
        Fire an ``actions``, or ``cleanup`` event on a given component.
        """
        for callback in component.get(event_name, []):
            callback()

    @hookenv.cached
    def not_ready(self, component):
        """
        Return a list of predicates that are not ready.
        """
        unready = []
        for req in component.get('requires', []):
            if isinstance(req, type):
                req = req()
            real_req = req
            if hasattr(req, 'is_ready'):
                real_req = req.is_ready
            if not real_req():
                unready.append(req)
        return unready

    def is_ready(self, component):
        """
        Determine if a registered component is ready, by checking its ``requires`` items.
        """
        return self.not_ready(component) == []

    def save_ready(self, component):
        """
        Save an indicator that the given component is now ready.
        """
        charmdata.kv.set('servicemanager.ready.%s' % component['name'], True)

    def save_lost(self, component):
        """
        Save an indicator that the given component is no longer ready.
        """
        charmdata.kv.set('servicemanager.ready.%s' % component['name'], False)

    def was_ready(self, component):
        """
        Determine if the given component was previously ready.
        """
        return charmdata.kv.get('servicemanager.ready.%s' % component['name'], False)
