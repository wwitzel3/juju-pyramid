# Copyright 2014-2015 Canonical Limited.
#
# This file is part of charm-helpers.
#
# charm-helpers is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License version 3 as
# published by the Free Software Foundation.
#
# charm-helpers is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with charm-helpers.  If not, see <http://www.gnu.org/licenses/>.

import os
import yaml
from functools import partial
from charmhelpers.core import hookenv
from charmhelpers.core import templating

from charmhelpers.core import charmdata


class Relation(object):
    """
    Base class for relation handler classes.
    """
    relation_name = None
    required_keys = []
    optional = False

    def __init__(self, relation_name=None, required_keys=None, optional=None,
                 datastore=charmdata.kv, cache=hookenv.cache):
        """
        Create a new Relation handler.

        :param str relation_name: Name (**not** interface) of the relation to
            manage.  You can override the `relation_name` defined by the class
            by passing a new `relation_name` to the constructor.  The
            `relation_name` *must* either be defined by the class or provided
            to the constructor.
        :param list required_keys: List of keys that must be set on the relation
            for it to be considered ready.  If no keys are defined, then a
            relation is considered ready if a unit is attached.  You can override
            the list of `required_keys` by passing a new list to the constructor.
        :param bool optional: Whether the relation is optional or not.  An
            optional relation is always considered ready, even if no units are
            connected, but the relation data stored in the `datastore` is still
            filtered based on the `required_keys`.
        :param object datastore: Where to store the filtered relation data.  By
            default, this is in :mod:`charmhelpers.core.charmdata`.  It is not
            recommended that you change this.
        :param object cache: Where to cache relation data to prevent unnecessary
            subprocess calls.  By default, this is in :mod:`hookenv.cache
            <charmhelpers.core.hookenv>`.  It is not recommended that you change
            this.
        """
        if relation_name is not None:
            self.relation_name = relation_name
        if self.relation_name is None:
            raise ValueError('No relation_name provided')
        if required_keys is not None:
            self.required_keys = required_keys
        if optional is not None:
            self.optional = optional
        self.datastore = datastore
        self.cache = cache

    def __str__(self):
        units_info = []
        for unit, data in self._unfiltered_data().items():
            missing_keys = set(self.required_keys) - set(data.keys())
            if missing_keys:
                unit_info = "missing({})".format(', '.join(missing_keys))
            else:
                unit_info = "ready"
            units_info.append('{}={}'.format(unit, unit_info))
        return '<{name} ready={ready} {units}>'.format(
            name=type(self).__name__,
            ready=self.is_ready(),
            units=' '.join(units_info),
        )

    def unit_ready(self, unit_name, unit_data):
        """
        Check the data for a single unit and indicate whether that unit is ready.
        """
        return set(unit_data.keys()).issuperset(set(self.required_keys))

    def connected_units(self):
        """
        Returns a list of the names of all units connected on this relation.
        """
        cache_key = 'Relation.connected_units(%s)' % self.relation_name
        if cache_key in hookenv.cache:
            return hookenv.cache[cache_key]
        units = []
        for relid in hookenv.relation_ids(self.relation_name):
            for unit in hookenv.related_units(relid):
                units.append(unit)
        hookenv.cache[cache_key] = units
        return units

    def _unfiltered_data(self):
        cache_key = 'Relation._unfiltered_data(%s, %s)' % (
            self.relation_name, self.required_keys)
        if cache_key not in self.cache:  # cache for the duration of the hook
            self.cache[cache_key] = data = {}
            for relid in hookenv.relation_ids(self.relation_name):
                for unit in hookenv.related_units(relid):
                    data[unit] = hookenv.relation_get(unit=unit, rid=relid)
        return self.cache[cache_key]

    def filtered_data(self, remote_service=None):
        """
        Returns a filtered list of per-unit relation data, for those units which
        have set all of the ``required_keys``.  If :param:`remote_service` is given,
        only units for that remote service are returned (useful in :meth:`provide`
        methods).
        """
        cache_key = 'Relation.filtered_data(%s, %s)' % (
            self.relation_name, self.required_keys)
        if cache_key not in self.cache:  # cache for the duration of the hook
            self.cache[cache_key] = filtered_data = {}
            for unit_name, unit_data in self._unfiltered_data().iteritems():
                if self.unit_ready(unit_name, unit_data):
                    filtered_data[unit_name] = unit_data

        filtered_data = self.cache[cache_key]
        if remote_service is not None:
            filtered_data = {k: v
                             for k, v in filtered_data.iteritems()
                             if k.startswith(remote_service)}
        return filtered_data

    def store_data(self):
        """
        Store all filtered relation data is stored in
        :class:`charmdata <charmhelpers.core.charmdata.Storage>` under ``relations.ready``,
        which can be retrieved like:

            from charmhelpers.core import charmdata
            data = charmdata.kv['relations.ready'][relation_name][unit_name]

        An example usage of this might be in a :func:`template`:

            [config]
            database = {{ (charmdata.kv['relations.ready']['db'].values()|first)['host'] }}
        """
        stored_data = self.datastore.get('relations.ready', {})
        stored_data[self.relation_name] = self.filtered_data()
        self.datastore.set('relations.ready', stored_data)

    def provide(self, remote_service, all_ready):
        """
        Provide data to the other side of the relation.

        This should be implemented by subclasses.

        :param str remote_service: Name of the remote service to which this
            relation will be providing data
        :param bool all_ready: Whether all ``requires`` predicates for this
            Charm component have been met
        """
        return {}

    def is_ready(self):
        """
        Determine if this relation is "ready".

        A relation is ready if there is at least one unit that satisfies
        all of the ``required_keys``, or, if the relation is ``optional``,
        if there are no units connected.  (A unit connected to an ``optional``
        relation must provide all of the ``required_keys`` or the relation
        is no longer considered ready.)
        """
        filtered_data = self.filtered_data()
        return self.optional or len(filtered_data) > 0


def config_eq(option, value):
    """
    Returns a predicate that asserts that the given config option is equal to
    the given value.

    Values of ``None`` are normalized to empty strings, since it is impossible
    to properly "unset" a config value once it has been set; it can only be
    set to an empty string.
    """
    def _config_eq():
        expected_value = value
        current_value = hookenv.config().get(option)
        if expected_value is None:
            expected_value = ''
        if current_value is None:
            current_value = ''
        return current_value == expected_value
    return _config_eq


def config_ne(option, value):
    """
    Returns a predicate that asserts that the given config option is not equal
    to the given value.

    Values of ``None`` are normalized to empty strings, since it is impossible
    to properly "unset" a config value once it has been set; it can only be
    set to an empty string.
    """
    def _config_ne():
        unexpected_value = value
        current_value = hookenv.config().get(option)
        if unexpected_value is None:
            unexpected_value = ''
        if current_value is None:
            current_value = ''
        return current_value != unexpected_value
    return _config_ne


def config_not_default(option):
    """
    Returns a predicate that asserts that the given config option is not equal
    to its default value.

    Values of ``None`` are normalized to empty strings, since it is impossible
    to properly "unset" a config value once it has been set; it can only be
    set to an empty string.
    """
    def _config_not_default():
        with open(os.path.join(hookenv.charm_dir(), 'config.yaml')) as fp:
            options = yaml.load(fp).get('options', {})
            default_value = options.get(option).get('default')
        current_value = hookenv.config().get(option)
        if default_value is None:
            default_value = ''
        if current_value is None:
            current_value = ''
        return current_value != default_value
    return _config_not_default


def config_is_set(option):
    """
    Returns a predicate that asserts that the given config option is set to a
    non-False value.

    This is equivalent to :func:`config_ne(option, False) <config_ne>`, but
    can be a bit more clear.
    """
    return config_ne(option, False)


def template(source, target, context=None, owner='root', group='root', perms=0o444):
    """
    Returns an action callback that will render a Jinja2 template.

    The template is provided a context which includes a ``ctx`` dict, containing
    all of the information returned from :function:`charmhelpers.core.hookenv.execution_environment`
    as well as a ``charmdata.kv`` dict with any data persisted via
    :module:`charmhelpers.core.charmdata`.

    :param str source: The template source file, relative to ``$CHARM_DIR/templates``
    :param str target: The target to write the rendered template to
    :param dict context: Additional context to be provided to the template
    :param str owner: The owner of the rendered file (default: root)
    :param str group: The group of the rendered file (default: root)
    :param int perms: The permissions of the rendered file (default 0o444)
    """
    def _template():
        _context = dict(context,
                        ctx=hookenv.execution_environment(),
                        config=hookenv.config(),
                        charmdata={'kv': charmdata.kv.getrange()})
        templating.render(source, target, _context, owner, group, perms)
    return _template


def open_ports(*ports):
    """
    Returns an action callback that will open the given ports when called.

    Roughly equivalent to:

        lambda: map(hookenv.open_port, ports)

    However, ports can be given as individual ports (``open_ports(80, 443)``),
    or a list of ports (``open_ports([80, 443])``).
    """
    def _open_ports():
        for port in ports:
            if not isinstance(port, (list, tuple)):
                port = [port]
            for _port in port:
                hookenv.open_port(_port)
    return _open_ports


def close_ports(*ports):
    """
    Returns an action callback that will close the given ports when called.

        lambda: map(hookenv.open_port, ports)

    However, ports can be given as individual ports (``close_ports(80, 443)``),
    or a list of ports (`close_ports([80, 443])``).
    """
    def _close_ports():
        for port in ports:
            if not isinstance(port, (list, tuple)):
                port = [port]
            for _port in port:
                hookenv.close_port(_port)
    return _close_ports


def service_restart(service_name):
    """
    Returns an action callback that will restart the given service.

    Equivalent to:

        functools.partial(hookenv.service_restart, service_name)
    """
    return partial(hookenv.service_restart, service_name)


def service_reload(service_name):
    """
    Returns an action callback that will reload the given service.

    Equivalent to:

        functools.partial(hookenv.service_reload, service_name)
    """
    return partial(hookenv.service_reload, service_name)


def service_stop(service_name):
    """
    Returns an action callback that will stop the given service.

    Equivalent to:

        functools.partial(hookenv.service_stop, service_name)
    """
    return partial(hookenv.service_stop, service_name)
