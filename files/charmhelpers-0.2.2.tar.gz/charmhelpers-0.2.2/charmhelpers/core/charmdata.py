import atexit
import contextlib
import datetime
import json
import os
import pprint
import sqlite3
import sys
import unittest


class Storage(object):
    """Simple key value database for local unit state within charms.

    Modifications are automatically committed at hook exit. That's
    currently regardless of exit code.

    To support dicts, lists, integer, floats, and booleans values
    are automatically json encoded/decoded.
    """
    def __init__(self, path=None):
        self.db_path = path
        if path is None:
            self.db_path = os.path.join(
                os.environ.get('CHARM_DIR', ''), '.unit-state.db')
        self.conn = sqlite3.connect('%s' % self.db_path)
        self.cursor = self.conn.cursor()
        self.revision = None
        self._init()

    def _scoped_query(self, stmt, params=None):
        if params is None:
            params = []
        return stmt, params
        if self.revision:
            stmt += " and revision=?"
            params.append(self.revision)
        return stmt, params

    def get(self, key, default=None, record=False):
        self.cursor.execute(
            *self._scoped_query(
                'select data from kv where key=?', [key]))
        result = self.cursor.fetchone()
        if not result:
            return default
        if record:
            return Record(json.loads(result[0]))
        return json.loads(result[0])

    def __getitem__(self, key):
        return self.get(key)

    def getrange(self, key_prefix=None, strip=False):
        if key_prefix is not None:
            stmt = "select key, data from kv where key like '%s_%%'" % key_prefix
        else:
            stmt = "select key, data from kv"
        self.cursor.execute(*self._scoped_query(stmt))
        result = self.cursor.fetchall()

        if not result:
            return None
        if not strip:
            key_prefix = ''
        return {k[len(key_prefix):]: json.loads(v) for k, v in result}

    def update(self, mapping, prefix=""):
        for k, v in mapping.items():
            self.set("%s%s" % (prefix, k), v)

    def unset(self, key):
        self.cursor.execute('delete from kv where key=?', [key])
        if self.revision:
            self.cursor.execute(
                'insert into kv_revisions values (?, ?, ?)',
                [self.revision, key, 'DELETED'])

    def set(self, key, value):
        serialized = json.dumps(value)

        self.cursor.execute(
            'select data from kv where key=?', [key])
        exists = self.cursor.fetchone()

        # Skip mutations to the same value
        if exists:
            if exists[0] == serialized:
                return value

        if not exists:
            self.cursor.execute(
                'insert into kv (key, data) values (?, ?)',
                (key, serialized))
        else:
            self.cursor.execute('''
            update kv
            set data = ?
            where key = ?''', [serialized, key])

        # Save
        if not self.revision:
            return value

        self.cursor.execute(
            'select 1 from kv_revisions where key=? and revision=?',
            [key, self.revision])
        exists = self.cursor.fetchone()

        if not exists:
            self.cursor.execute(
                '''insert into kv_revisions (
                revision, key, data) values (?, ?, ?)''',
                (self.revision, key, serialized))
        else:
            self.cursor.execute(
                '''
                update kv_revisions
                set data = ?
                where key = ?
                and   revision = ?''',
                [serialized, key, self.revision])

        return value

    def __setitem__(self, key, value):
        return self.set(key, value)

    def delta(self, mapping, prefix):
        """
        Store mapping and return a delta containing values that
        have changed.

        """
        previous = self.getrange(prefix, strip=True)
        pk = set(previous.keys())
        ck = set(mapping.keys())
        delta = DeltaSet()

        # added
        for k in ck.difference(pk):
            delta[k] = Delta((None, mapping[k]))

        # removed
        for k in pk.difference(ck):
            delta[k] = Delta((previous[k], None))

        # changed
        for k in pk.intersection(ck):
            c = mapping[k]
            p = previous[k]
            if c != p:
                delta[k] = Delta((p, c))

        if delta:
            return delta
        return None

    @contextlib.contextmanager
    def hook_scope(self, name, context=True):
        """Scope all future interactions to the current hook execution
        revision."""
        assert not self.revision
        self.cursor.execute(
            'insert into hooks (hook, date) values (?, ?)',
            (sys.argv[0],
             datetime.datetime.now().isoformat()))
        self.revision = self.cursor.lastrowid
        if not context:
            yield self.revision
            raise StopIteration()
        try:
            yield self.revision
            self.revision = None
        except:
            self.flush(False)
            self.revision = None
            raise
        else:
            self.flush()

    def flush(self, save=True):
        if save:
            self.conn.commit()
        else:
            self.conn.rollback()

    def _init(self):
        self.cursor.execute('''
            create table if not exists kv (
               key text,
               data text,
               primary key (key)
               )''')
        self.cursor.execute('''
            create table if not exists kv_revisions (
               key text,
               revision integer,
               data text,
               primary key (key, revision)
               )''')
        self.cursor.execute('''
            create table if not exists hooks (
               version integer primary key autoincrement,
               hook text,
               date text
               )''')
        self.conn.commit()
        atexit.register(self.conn.commit)

    def gethistory(self, key):
        self.cursor.execute(
            'select revision, key, data from kv_revisions where key=?', [key])
        return self.cursor.fetchall()

    def debug(self):
        self.cursor.execute('select * from kv')
        pprint.pprint(self.cursor.fetchall())

        self.cursor.execute('select * from kv_revisions')
        import pprint
        pprint.pprint(self.cursor.fetchall())


class Record(dict):

    __slots__ = ()

    def __getattr__(self, k):
        if k in self:
            return self[k]
        raise AttributeError(k)


class DeltaSet(dict):

    __slots__ = ()

    def __getattr__(self, k):
        if k in self:
            return self[k]
        raise AttributeError(k)


class Delta(tuple):

    __slots__ = ()

    @property
    def current(self):
        return self[1]

    @property
    def previous(self):
        return self[0]


if 'CHARM_DIR' in os.environ:
    kv = Storage()
else:
    kv = None


class StorageTest(unittest.TestCase):

    def test_hook_scope(self):
        kv = Storage(':memory:')
        try:
            with kv.hook_scope('xyz') as rev:
                self.assertEqual(rev, 1)
                kv.set('a', 1)
                raise RuntimeError('x')
        except RuntimeError:
            self.assertEqual(kv.get('a'), None)

        with kv.hook_scope('xyz') as rev:
            self.assertEqual(rev, 1)
            kv.set('a', 1)
        self.assertEqual(kv.get('a'), 1)

        kv.revision = None

        with kv.hook_scope('xyz') as rev:
            self.assertEqual(rev, 2)
            kv.set('a', False)
            kv.set('a', True)
        self.assertEqual(kv.get('a'), True)

        # History doesn't decode atm
        self.assertEqual(
            kv.gethistory('a'),
            [(1, 'a', '1'), (2, 'a', 'true')])

    def test_delta(self):
        kv = Storage(':memory:')
        kv.update({'a': 1, 'b': 2.2}, prefix="x")
        delta = kv.delta({'a': 0, 'c': False}, prefix='x')
        self.assertEqual(
            delta,
            {'a': (1, 0), 'b': (2.2, None), 'c': (None, False)})
        self.assertEqual(delta.a.previous, 1)
        self.assertEqual(delta.a.current, 0)
        self.assertEqual(delta.c.previous, None)
        self.assertEqual(delta.a.current, False)

    def test_update(self):
        kv = Storage(':memory:')
        kv.update({'v_a': 1, 'v_b': 2.2})
        self.assertEqual(kv.getrange('v_'), {'v_a': 1, 'v_b': 2.2})

        kv.update({'a': False, 'b': True}, prefix='x_')
        self.assertEqual(
            kv.getrange('x_', True), {'a': False, 'b': True})

    def test_keyrange(self):
        kv = Storage(':memory:')
        kv.set('docker.net_mtu', 1)
        kv.set('docker.net_nack', True)
        kv.set('docker.net_type', 'vxlan')
        self.assertEqual(
            kv.getrange('docker'),
            {'docker.net_mtu': 1, 'docker.net_type': 'vxlan',
             'docker.net_nack': True})
        self.assertEqual(
            kv.getrange('docker.', True),
            {'net_mtu': 1, 'net_type': 'vxlan', 'net_nack': True})

    def test_get_set_unset(self):
        kv = Storage(':memory:')
        kv.hook_scope('test')
        kv.set('hello', 'saucy')
        kv.set('hello', 'world')
        self.assertEqual(kv.get('hello'), 'world')
        kv.flush()
        kv.unset('hello')
        self.assertEqual(kv.get('hello'), None)
        kv.flush(False)
        self.assertEqual(kv.get('hello'), 'world')

if __name__ == '__main__':
    unittest.main()
