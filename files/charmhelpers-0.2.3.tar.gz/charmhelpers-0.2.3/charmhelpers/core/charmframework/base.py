# Copyright 2014-2015 Canonical Limited.
#
# This file is part of charm-helpers.
#
# charm-helpers is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License version 3 as
# published by the Free Software Foundation.
#
# charm-helpers is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with charm-helpers.  If not, see <http://www.gnu.org/licenses/>.

from charmhelpers.core import hookenv
from charmhelpers.core import unitdata


class Manager(object):
    """
    Manage all hooks, based on a set of charm component definitions.

    Component definitions are dicts in the following format
    (all fields are optional)::

        {
            "name": <name of component>,
            "provides": <list of providers>,
            "requires": <list of predicates>,
            "callbacks": <list of callbacks>,
            "cleanup": <list of callbacks>,
        }

    :ivar str name: Descriptive name
    :ivar list provides: Data providers, most likely subclasses of
        :class:`~charmhelpers.core.charmframework.helpers.Relation`,
        although any object (or class) which has a ``relation_name`` attribute
        and a ``provide`` method which accepts the remote service name and a
        flag indicating whether the callbacks have been fired, and which returns
        a *dict* of data to send to that remote service.
    :ivar list requires: Predicates, all of which must pass for the ``callbacks``
        to be fired.  :class:`~charmhelpers.core.charmframework.helpers.Relation`
        subclasses or instances can be used as predicates in addition to simple
        no-argument functions which return a *bool*.  Any
        :class:`~charmhelpers.core.charmframework.helpers.Relation` subclass
        or instance will have its
        :meth:`~charmhelpers.core.charmframework.helpers.Relation.store_data`
        method called.  See :mod:`~charmhelpers.core.charmframework.helpers`
        for several helpers that can be used to construct predicates.
    :ivar list callbacks: Callbacks that are fired if all ``requires`` predicates
        pass.  They will be passed no arguments.  See
        :mod:`~charmhelpers.core.charmframework.helpers` for several helpers
        that can be used to construct callbacks.
    :ivar list cleanup: Callbacks that are fired when stopping the service.

    Examples:

    The following registers a component which depends on a mongodb relation
    and a ``password`` option being changed from its default value, and which
    runs a custom ``db_migrate`` function, adds a system user, renders a couple
    of templates, starts the system service 'myservice', and finally opens a
    couple of ports::

        from charmhelpers.core import charmframework
        from charmhelpers.core import host
        from functools import partial

        class MongoRelation(charmframework.helpers.Relation):
            relation_name = 'mongo'
            required_keys = ['hostname', 'port']

        manager = charmframework.Manager([
            {
                'provides': [
                    HttpRelation,
                ],
                'requires': [
                    MongoRelation,
                    charmframwork.helpers.config_not_default('password'),
                ],
                'callbacks': [
                    db_migrate,
                    partial(host.adduser, 'myuser'),
                    charmframework.helpers.render_template(source='myservice.conf'),
                    charmframework.helpers.render_template(source='myservice.ini',
                                                           target='/etc/myservice.ini',
                                                           owner='myuser', perms=0400),
                    charmframework.helpers.service_restart('myservice'),
                    charmframework.helpers.open_ports(80, 443),
                ],
                'cleanup': [
                    charmframework.helpers.close_ports(80, 443),
                    charmframework.helpers.service_stop('myservice'),
                ],
            },
        ])
        manager.manage()
    """

    def __init__(self, components):
        self.components = components
        for i, component in enumerate(components):
            component.setdefault('name', 'component-%d' % i)

    def manage(self):
        """
        Handle the current hook by doing The Right Thing with the registered components.
        """
        hook_name = hookenv.hook_name()
        if hook_name == 'stop':
            self.run_cleanup()
        else:
            self.run_callbacks()
            self.provide_data()
        cfg = hookenv.config()
        if cfg.implicit_save:
            cfg.save()

    def provide_data(self):
        """
        Set the relation data for each provider in the ``provides`` list.

        A provider can be a class or an instance, and must have a ``relation_name``
        attribute, which indicates which relation is applies to, and a
        ``provide(remote_service, all_ready)`` method, where ``remote_service``
        is the name of the Juju service on the other end of the relation, and
        ``all_ready`` is a boolean indicating whether all of the requirements
        for the component were satisfied and the callbacks were run.

        Note that the providers are called after the requirements are
        checked and the callbacks (possibly) run, since the callbacks may
        generate some of the data to be provided.
        """
        for component in self.components:
            component_ready = self.is_ready(component)
            for provider in component.get('provides', []):
                if isinstance(provider, type):
                    provider = provider()
                for relid in hookenv.relation_ids(provider.relation_name):
                    units = hookenv.related_units(relid)
                    if not units:
                        continue
                    remote_service = units[0].split('/')[0]
                    data = provider.provide(remote_service, component_ready)
                    if data:
                        hookenv.relation_set(relid, data)

    def run_callbacks(self):
        """
        Check all components' ``requires`` predicates and run either ``callbacks``
        or ``cleanup`` actions.
        """
        for component in self.components:
            self.store_data(component)
            if self.is_ready(component):
                self.fire_event('callbacks', component)
                self.save_ready(component)
            else:
                hookenv.log('Component {} blocked on: [{}]'.format(
                    component['name'],
                    ', '.join(map(str, self.not_ready(component))),
                ))
                if self.was_ready(component):
                    self.fire_event('cleanup', component)
                self.save_lost(component)

    def run_cleanup(self):
        """
        Unconditionally run all components' ``cleanup`` actions.
        """
        for component in self.components:
            self.fire_event('cleanup', component)

    def store_data(self, component):
        for req in component.get('requires', []):
            if isinstance(req, type):
                req = req()
            if hasattr(req, 'store_data'):
                req.store_data()

    def fire_event(self, event_name, component):
        """
        Fire an ``actions``, or ``cleanup`` event on a given component.
        """
        for callback in component.get(event_name, []):
            callback()

    @hookenv.cached
    def not_ready(self, component):
        """
        Return a list of predicates that are not ready.
        """
        unready = []
        for req in component.get('requires', []):
            if isinstance(req, type):
                req = req()
            real_req = req
            if hasattr(req, 'is_ready'):
                real_req = req.is_ready
            if not real_req():
                unready.append(req)
        return unready

    def is_ready(self, component):
        """
        Determine if a registered component is ready, by checking its ``requires`` items.
        """
        return self.not_ready(component) == []

    def save_ready(self, component):
        """
        Save an indicator that the given component is now ready.
        """
        unitdata.kv.set('servicemanager.ready.%s' % component['name'], True)

    def save_lost(self, component):
        """
        Save an indicator that the given component is no longer ready.
        """
        unitdata.kv.set('servicemanager.ready.%s' % component['name'], False)

    def was_ready(self, component):
        """
        Determine if the given component was previously ready.
        """
        return unitdata.kv.get('servicemanager.ready.%s' % component['name'], False)
