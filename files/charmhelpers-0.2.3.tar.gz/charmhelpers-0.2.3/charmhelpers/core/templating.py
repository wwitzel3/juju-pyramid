# Copyright 2014-2015 Canonical Limited.
#
# This file is part of charm-helpers.
#
# charm-helpers is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License version 3 as
# published by the Free Software Foundation.
#
# charm-helpers is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with charm-helpers.  If not, see <http://www.gnu.org/licenses/>.

import os

from charmhelpers.core import host
from charmhelpers.core import hookenv


def render(source, target, context, owner='root', group='root',
           perms=0o444, templates_dir=None, encoding='UTF-8'):
    """
    Render a Jinja2 template.

    :param str source: Path to template, relative to ``templates_dir``.
    :param str target: Path (generally absolute) to write template to.  If
        ``None``, no file will be written (in case only the returned rendered
        template string is desired).
    :param dict context: Variables available to the template.
    :param str owner: Passed through to :func:`~charmhelpers.core.host.write_file`.
    :param str group: Passed through to :func:`~charmhelpers.core.host.write_file`.
    :param str perms: Passed through to :func:`~charmhelpers.core.host.write_file`.
    :param str templates_dir: Base path for the templates.  Defaults to ``$CHARM_DIR/templates``.
    :param str encoding: Encoding to use when writing the file.
    :returns: The rendered template.

    Note: Using this requires `python-jinja2 <http://jinja.pocoo.org/>`_; if it
    is not installed, calling this will attempt to use
    :func:`charmhelpers.fetch.apt_install` to install it.
    """
    try:
        from jinja2 import FileSystemLoader, Environment, exceptions
    except ImportError:
        try:
            from charmhelpers.fetch import apt_install
        except ImportError:
            hookenv.log('Could not import jinja2, and could not import '
                        'charmhelpers.fetch to install it',
                        level=hookenv.ERROR)
            raise
        apt_install('python-jinja2', fatal=True)
        from jinja2 import FileSystemLoader, Environment, exceptions

    if templates_dir is None:
        templates_dir = os.path.join(hookenv.charm_dir(), 'templates')
    loader = Environment(loader=FileSystemLoader(templates_dir))
    try:
        source = source
        template = loader.get_template(source)
    except exceptions.TemplateNotFound as e:
        hookenv.log('Could not load template %s from %s.' %
                    (source, templates_dir),
                    level=hookenv.ERROR)
        raise e
    content = template.render(context)
    host.mkdir(os.path.dirname(target), owner, group, perms=0o755)
    host.write_file(target, content.encode(encoding), owner, group, perms)
